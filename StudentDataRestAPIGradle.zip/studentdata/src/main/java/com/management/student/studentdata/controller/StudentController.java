package com.management.student.studentdata.controller;

import java.util.List;

import javax.validation.Valid;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.management.student.studentdata.model.Student;
import com.management.student.studentdata.respository.StudentRepository;

/**
 * This is the controller class for calling different requests. It checks the
 * URL mapping and do the corresponding action
 * 
 * @author Vishnu EK
 * @version 1.0
 * @since 19 jan 2019
 */
@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentRepository repository;

	/**
	 * This method is used to find all students
	 * 
	 * @return list of students as List<Student>
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public List<Student> getAllStudentDetails() {
		System.out.println("getAllStudentDetails");
		return repository.findAll();
	}

	/**
	 * This method is used to find the student details by id
	 * 
	 * @param id as ObjectId
	 * @return Student
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Student getStudentById(@PathVariable("id") ObjectId id) {
		System.out.println("getStudentById");
		return repository.findBy_id(id);
	}

	/**
	 * This method is used to update the student details by using id
	 * 
	 * @param id      as ObjectId
	 * @param student as Student
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public void updateStudentById(@PathVariable("id") ObjectId id, @Valid @RequestBody Student student) {
		System.out.println("updateStudentById");
		student.set_id(id);
		repository.save(student);
	}

	/**
	 * This method is used to save the student details
	 * 
	 * @param student as Student
	 * @return student as Student
	 */
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public Student saveStudentDetails(@Valid @RequestBody Student student) {
		System.out.println("saveStudentDetails");
		student.set_id(ObjectId.get());
		repository.save(student);
		return student;
	}

	/**
	 * This method is used to remove the student by using id
	 * 
	 * @param id as ObjectId
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void removeStudentDetails(@PathVariable ObjectId id) {
		System.out.println("removeStudentDetails");
		repository.delete(repository.findBy_id(id));
	}

}
