package com.management.student.studentdata.respository;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.management.student.studentdata.model.Student;

/**
 * Student specific {@link org.springframework.data.repository.Repository}
 * interface
 * 
 * @author Vishnu EK
 * @version 1.0
 * @since 19 Jan 2019
 */
public interface StudentRepository extends MongoRepository<Student, String> {

	/**
	 * find student object by using id
	 * 
	 * @param _id
	 * @return student the model
	 */
	Student findBy_id(ObjectId _id);
}
