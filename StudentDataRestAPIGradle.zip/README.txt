- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
I have created "Management" Database and "studentInfo" collection for this.

and 

Tested this API using Postman software (GET,POST,PUT,DELETE requests)..